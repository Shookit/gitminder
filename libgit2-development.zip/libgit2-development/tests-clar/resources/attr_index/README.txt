This contains files for testing when the index and the workdir differ
