libgit2 examples
================

These examples are meant as thin, easy-to-read snippets for Docurium
(https://github.com/github/docurium) rather than full-blown
implementations of Git commands.  They are not vetted as carefully
for bugs, error handling, or cross-platform compatibility as the
rest of the code in libgit2, so copy with some caution.

For HTML versions, check "Examples" at http://libgit2.github.com/libgit2

